const API_URL = 'http://localhost:5000/api/tasks';

let currentFilter = 'all';
let tasks = [];

// DOM elements
const taskInput = document.getElementById('taskInput');
const addBtn = document.getElementById('addBtn');
const taskList = document.getElementById('taskList');
const filterBtns = document.querySelectorAll('.filter-btn');

// Fetch all tasks
async function fetchTasks() {
  const res = await fetch(API_URL);
  tasks = await res.json();
  renderTasks();
}

// Render tasks based on filter
function renderTasks() {
  let filtered = tasks;
  if (currentFilter === 'pending') {
    filtered = tasks.filter(t => t.status === 'pending');
  } else if (currentFilter === 'completed') {
    filtered = tasks.filter(t => t.status === 'completed');
  }

  if (filtered.length === 0) {
    taskList.innerHTML = `<li style="justify-content:center; border-left-color:transparent; opacity:0.5;">No tasks</li>`;
    return;
  }

  taskList.innerHTML = filtered.map(task => `
    <li data-id="${task.id}">
      <span class="task-title">${task.title}</span>
      <span class="task-status ${task.status}">${task.status}</span>
      <div class="task-actions">
        <button class="toggle-btn" data-id="${task.id}">🔄</button>
        <button class="delete-btn" data-id="${task.id}">✕</button>
      </div>
    </li>
  `).join('');

  // Attach event listeners to buttons
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', toggleTask);
  });
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', deleteTask);
  });
}

// Add new task
async function addTask() {
  const title = taskInput.value.trim();
  if (!title) return alert('Please enter a task');

  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, status: 'pending' })
  });
  const newTask = await res.json();
  tasks.push(newTask);
  renderTasks();
  taskInput.value = '';
}

// Toggle task status
async function toggleTask(e) {
  const id = e.target.dataset.id;
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  const newStatus = task.status === 'pending' ? 'completed' : 'pending';
  await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: newStatus })
  });
  task.status = newStatus;
  renderTasks();
}

// Delete task
async function deleteTask(e) {
  const id = e.target.dataset.id;
  if (!confirm('Delete this task?')) return;
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  tasks = tasks.filter(t => t.id !== id);
  renderTasks();
}

// Filter buttons
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderTasks();
  });
});

// Event listeners
addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') addTask();
});

// Initial load
fetchTasks();