const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 50001;

// Middleware
app.use(cors());
app.use(express.json());

// Data paths
const DATA_DIR = path.join(__dirname, 'data');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Helper functions
const readData = (filePath) => {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
  }
  const data = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(data);
};

const writeData = (filePath, data) => {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

// ============= PRODUCTS API =============

// Get all products
app.get('/api/products', (req, res) => {
  try {
    const products = readData(PRODUCTS_FILE);
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get product by ID
app.get('/api/products/:id', (req, res) => {
  try {
    const products = readData(PRODUCTS_FILE);
    const product = products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// Add new product
app.post('/api/products', (req, res) => {
  try {
    const { name, category, price, stock, description, image } = req.body;
    if (!name || !price) {
      return res.status(400).json({ error: 'Name and price are required' });
    }
    const products = readData(PRODUCTS_FILE);
    const newProduct = {
      id: uuidv4(),
      name,
      category: category || 'Uncategorized',
      price: parseFloat(price),
      stock: parseInt(stock) || 0,
      description: description || '',
      image: image || 'https://via.placeholder.com/200',
      rating: 0,
      sales: 0,
      createdAt: new Date().toISOString()
    };
    products.push(newProduct);
    writeData(PRODUCTS_FILE, products);
    res.status(201).json(newProduct);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add product' });
  }
});

// Update product
app.put('/api/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, price, stock, description, image } = req.body;
    const products = readData(PRODUCTS_FILE);
    const index = products.findIndex(p => p.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Product not found' });
    }
    products[index] = {
      ...products[index],
      name: name || products[index].name,
      category: category || products[index].category,
      price: price ? parseFloat(price) : products[index].price,
      stock: stock !== undefined ? parseInt(stock) : products[index].stock,
      description: description || products[index].description,
      image: image || products[index].image
    };
    writeData(PRODUCTS_FILE, products);
    res.json(products[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// Delete product
app.delete('/api/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    let products = readData(PRODUCTS_FILE);
    products = products.filter(p => p.id !== id);
    writeData(PRODUCTS_FILE, products);
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// ============= ORDERS API =============

// Get all orders
app.get('/api/orders', (req, res) => {
  try {
    const orders = readData(ORDERS_FILE);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Create new order
app.post('/api/orders', (req, res) => {
  try {
    const { customerName, customerEmail, items, shippingAddress } = req.body;
    if (!customerName || !items || items.length === 0) {
      return res.status(400).json({ error: 'Customer name and items are required' });
    }

    // Calculate total
    let totalAmount = 0;
    items.forEach(item => {
      totalAmount += item.price * item.quantity;
    });

    const orders = readData(ORDERS_FILE);
    const newOrder = {
      id: `ORD-${String(orders.length + 1).padStart(3, '0')}`,
      customerName,
      customerEmail: customerEmail || '',
      items,
      totalAmount,
      status: 'pending',
      orderDate: new Date().toISOString(),
      shippingAddress: shippingAddress || 'No address provided'
    };
    orders.push(newOrder);
    writeData(ORDERS_FILE, orders);

    // Update product stock
    const products = readData(PRODUCTS_FILE);
    items.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (product) {
        product.stock -= item.quantity;
        product.sales += item.quantity;
      }
    });
    writeData(PRODUCTS_FILE, products);

    res.status(201).json(newOrder);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// Update order status
app.put('/api/orders/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    const orders = readData(ORDERS_FILE);
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Order not found' });
    }
    orders[index].status = status;
    writeData(ORDERS_FILE, orders);
    res.json(orders[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update order' });
  }
});

// Delete order
app.delete('/api/orders/:id', (req, res) => {
  try {
    const { id } = req.params;
    let orders = readData(ORDERS_FILE);
    orders = orders.filter(o => o.id !== id);
    writeData(ORDERS_FILE, orders);
    res.json({ message: 'Order deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete order' });
  }
});

// ============= STATISTICS =============

app.get('/api/stats', (req, res) => {
  try {
    const products = readData(PRODUCTS_FILE);
    const orders = readData(ORDERS_FILE);

    const totalProducts = products.length;
    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    const totalSales = orders.reduce((sum, order) => {
      return sum + order.items.reduce((s, item) => s + item.quantity, 0);
    }, 0);
    const lowStock = products.filter(p => p.stock < 10).length;

    // Top products
    const topProducts = [...products]
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5);

    // Recent orders
    const recentOrders = [...orders]
      .sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate))
      .slice(0, 5);

    res.json({
      stats: {
        totalProducts,
        totalOrders,
        totalRevenue,
        totalSales,
        lowStock
      },
      topProducts,
      recentOrders
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 AddFlow Pro Server running on http://localhost:${PORT}`);
  console.log(`📊 API endpoints:`);
  console.log(`   - GET  /api/products`);
  console.log(`   - POST /api/products`);
  console.log(`   - GET  /api/orders`);
  console.log(`   - POST /api/orders`);
  console.log(`   - GET  /api/stats`);
});