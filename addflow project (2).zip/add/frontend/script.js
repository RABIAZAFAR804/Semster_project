const API_URL = 'http://localhost:50001/api';
let products = [];
let orders = [];

// ============= NAVIGATION =============
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.getElementById(btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'dashboard') loadDashboard();
    if (btn.dataset.tab === 'products') loadProducts();
    if (btn.dataset.tab === 'orders') loadOrders();
    if (btn.dataset.tab === 'create-order') populateProductSelects();
  });
});

// ============= DASHBOARD =============
async function loadDashboard() {
  try {
    const res = await fetch(`${API_URL}/stats`);
    const data = await res.json();
    
    document.getElementById('totalProducts').textContent = data.stats.totalProducts;
    document.getElementById('totalOrders').textContent = data.stats.totalOrders;
    document.getElementById('totalRevenue').textContent = `$${data.stats.totalRevenue.toFixed(2)}`;
    document.getElementById('lowStock').textContent = data.stats.lowStock;

    // Top Products
    const topList = document.getElementById('topProductsList');
    topList.innerHTML = data.topProducts.map(p => `
      <li>
        <span>${p.name}</span>
        <span>${p.sales} sold</span>
      </li>
    `).join('');

    // Recent Orders
    const recentList = document.getElementById('recentOrdersList');
    recentList.innerHTML = data.recentOrders.map(o => `
      <li>
        <span>${o.customerName}</span>
        <span class="order-status status-${o.status}">${o.status}</span>
      </li>
    `).join('');
  } catch (error) {
    console.error('Error loading dashboard:', error);
  }
}

// ============= PRODUCTS =============
async function loadProducts() {
  try {
    const res = await fetch(`${API_URL}/products`);
    products = await res.json();
    renderProducts(products);
    
    // Populate category filter
    const categories = [...new Set(products.map(p => p.category))];
    const filter = document.getElementById('categoryFilter');
    filter.innerHTML = '<option value="all">All Categories</option>' + 
      categories.map(c => `<option value="${c}">${c}</option>`).join('');
  } catch (error) {
    console.error('Error loading products:', error);
  }
}

function renderProducts(productsToRender) {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = productsToRender.map(p => {
    const stockStatus = p.stock > 10 ? 'in-stock' : p.stock > 0 ? 'low-stock' : 'out-of-stock';
    const stockLabel = p.stock > 10 ? 'In Stock' : p.stock > 0 ? 'Low Stock' : 'Out of Stock';
    return `
      <div class="product-card">
        <img src="${p.image}" alt="${p.name}" />
        <h4>${p.name}</h4>
        <div class="price">$${p.price.toFixed(2)}</div>
        <div class="stock">Stock: ${p.stock}</div>
        <span class="badge ${stockStatus}">${stockLabel}</span>
      </div>
    `;
  }).join('');
}

// Search and filter
document.getElementById('productSearch')?.addEventListener('input', filterProducts);
document.getElementById('categoryFilter')?.addEventListener('change', filterProducts);

function filterProducts() {
  const search = document.getElementById('productSearch').value.toLowerCase();
  const category = document.getElementById('categoryFilter').value;
  let filtered = products;
  if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search));
  if (category !== 'all') filtered = filtered.filter(p => p.category === category);
  renderProducts(filtered);
}

// ============= ORDERS =============
async function loadOrders() {
  try {
    const res = await fetch(`${API_URL}/orders`);
    orders = await res.json();
    const list = document.getElementById('ordersList');
    list.innerHTML = orders.map(o => `
      <div class="order-card">
        <div class="order-info">
          <h4>${o.customerName}</h4>
          <p>${o.id} • ${new Date(o.orderDate).toLocaleDateString()}</p>
          <p>${o.items.map(i => `${i.name} x${i.quantity}`).join(', ')}</p>
        </div>
        <div>
          <div style="font-weight:700;font-size:18px;">$${o.totalAmount.toFixed(2)}</div>
          <span class="order-status status-${o.status}">${o.status}</span>
        </div>
      </div>
    `).join('');
  } catch (error) {
    console.error('Error loading orders:', error);
  }
}

// ============= ADD PRODUCT =============
document.getElementById('productForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = {
    name: document.getElementById('pName').value,
    category: document.getElementById('pCategory').value,
    price: parseFloat(document.getElementById('pPrice').value),
    stock: parseInt(document.getElementById('pStock').value) || 0,
    description: document.getElementById('pDescription').value,
    image: document.getElementById('pImage').value || 'https://via.placeholder.com/200'
  };
  
  try {
    const res = await fetch(`${API_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      alert('✅ Product added successfully!');
      e.target.reset();
      loadProducts();
      // Switch to products tab
      document.querySelector('[data-tab="products"]').click();
    }
  } catch (error) {
    alert('❌ Failed to add product');
  }
});

// ============= CREATE ORDER =============
document.getElementById('addItemBtn')?.addEventListener('click', addOrderItem);

function addOrderItem() {
  const container = document.getElementById('orderItems');
  const itemDiv = document.createElement('div');
  itemDiv.className = 'order-item';
  itemDiv.innerHTML = `
    <select class="product-select" required>
      <option value="">Select Product</option>
    </select>
    <input type="number" class="quantity-input" placeholder="Qty" min="1" value="1" required />
    <button type="button" class="remove-item"><i class="fas fa-times"></i></button>
  `;
  container.appendChild(itemDiv);
  populateProductSelects();
  itemDiv.querySelector('.remove-item').addEventListener('click', () => {
    if (container.children.length > 1) itemDiv.remove();
  });
}

async function populateProductSelects() {
  try {
    const res = await fetch(`${API_URL}/products`);
    const products = await res.json();
    document.querySelectorAll('.product-select').forEach(select => {
      const currentValue = select.value;
      select.innerHTML = '<option value="">Select Product</option>' + 
        products.map(p => `<option value="${p.id}">${p.name} - $${p.price}</option>`).join('');
      if (currentValue) select.value = currentValue;
    });
  } catch (error) {
    console.error('Error populating products:', error);
  }
}

document.getElementById('orderForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const items = [];
  const itemRows = document.querySelectorAll('.order-item');
  let valid = true;
  
  itemRows.forEach(row => {
    const productId = row.querySelector('.product-select').value;
    const quantity = parseInt(row.querySelector('.quantity-input').value);
    if (productId && quantity > 0) {
      const product = products.find(p => p.id === productId);
      if (product) {
        items.push({
          productId: product.id,
          name: product.name,
          quantity: quantity,
          price: product.price
        });
      }
    } else {
      valid = false;
    }
  });
  
  if (!valid || items.length === 0) {
    alert('Please add at least one valid item');
    return;
  }
  
  const orderData = {
    customerName: document.getElementById('oCustomerName').value,
    customerEmail: document.getElementById('oCustomerEmail').value,
    shippingAddress: document.getElementById('oAddress').value,
    items: items
  };
  
  try {
    const res = await fetch(`${API_URL}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    if (res.ok) {
      alert('✅ Order created successfully!');
      e.target.reset();
      document.querySelector('[data-tab="orders"]').click();
      loadOrders();
    }
  } catch (error) {
    alert('❌ Failed to create order');
  }
});

// ============= INIT =============
loadDashboard();
loadProducts();
loadOrders();

console.log('🚀 AddFlow Pro loaded successfully!');